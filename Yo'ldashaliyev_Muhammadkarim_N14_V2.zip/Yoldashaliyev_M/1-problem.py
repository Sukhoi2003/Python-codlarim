n = input(">> ")
for i in n:
    if "left" in i:
        print(i)
    print(i)
