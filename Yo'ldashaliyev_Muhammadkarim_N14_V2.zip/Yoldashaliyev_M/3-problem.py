n = int(input("kun> "))
m = (input("oy> "))
a = int(input("Yil> "))
b = input("soat> ")
c = input("minut> ")
if m == '01':
    print(f"{n}-{'Yanvar'}, {a}, {b} Hours, {c}minut")
elif m == '02':
    print(f"{n}-{'Fevral'}, {a}, {b} Hours, {c}minut")
elif m == '03':
    print(f"{n}-{'Mart'}, {a}, {b} Hours, {c}minut")
elif m == '04':
    print(f"{n}-{'Aprel'}, {a}, {b} Hours, {c}minut")
elif m == '05':
    print(f"{n}-{'May'}, {a}, {b} Hours, {c}minut")
elif m == '06':
    print(f"{n}-{'Iyun'}, {a}, {b} Hours, {c}minut")
elif m == '07':
    print(f"{n}-{'Iyul'}, {a}, {b} Hours, {c}minut")
elif m == '08':
    print(f"{n}-{'Avgust'}, {a}, {b} Hours, {c}minut")
elif m == '09':
    print(f"{n}-{'Sentabr'}, {a}, {b} Hours, {c}minut")
elif m == '10':
    print(f"{n}-{'Oktabr'}, {a}, {b} Hours, {c}minut")
elif m == '11':
    print(f"{n}-{'Noyabr'}, {a}, {b} Hours, {c}minut")
elif m == '12':
    print(f"{n}-{'Dekabr'}, {a}, {b} Hours, {c}minut")

